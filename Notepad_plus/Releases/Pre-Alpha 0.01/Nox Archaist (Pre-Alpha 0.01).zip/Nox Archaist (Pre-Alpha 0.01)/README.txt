Nox Archaist
By: 6502 Workshop, LLC

Pre-Alpha Release 0.01
————————————————


To play the game engine demo, boot with na.program.dsk in drive 1, na.main.player.dsk in drive 2.




Technical Notes:

*Apple IIe or later with 128k RAM

*Testing has been done on AppleWIN 1.25.0.3 - 8 & a physical Apple IIe /w 128k
 




Distribution Notes:


Post to comp.sys.apple2.programmer on 3/30/2016
